(window.webpackJsonp=window.webpackJsonp||[]).push([["app~app_changePasswordForm~app_googleLogin~app_loginForm~app_nav~app_newPasswordForm~app_newUserForm~c87572b2"],{cRQp:
/*!*******************************!*\
  !*** ./src/shared/history.ts ***!
  \*******************************/
/*! exports provided: default */function(module,__webpack_exports__,__webpack_require__){"use strict";eval('__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var history__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! history */ "YHGo");\n\n/* harmony default export */ __webpack_exports__["default"] = (Object(history__WEBPACK_IMPORTED_MODULE_0__["createBrowserHistory"])());\n\n//# sourceURL=webpack:///./src/shared/history.ts?')}}]);