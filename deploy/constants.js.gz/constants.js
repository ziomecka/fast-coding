const PORT = 3000;

/** Cookies */
const HASH_COOKIE_MAX_AGE = 900000;
const HASH_COOKIE_NAME = 'fc-hash';

module.exports = { PORT, HASH_COOKIE_MAX_AGE, HASH_COOKIE_NAME };
